# Analytics

**Note**: This package may be soon deprecated in favor of `@atlaskit/analytics-next`.

Fire analytics events from React Components and then decorate and listen for them.

## Installation

```sh
yarn add @atlaskit/analytics
```

## Usage

Detailed docs and example usage can be found [here](https://atlaskit.atlassian.com/packages/core/analytics).
