export { default as StorageClient } from './main';
