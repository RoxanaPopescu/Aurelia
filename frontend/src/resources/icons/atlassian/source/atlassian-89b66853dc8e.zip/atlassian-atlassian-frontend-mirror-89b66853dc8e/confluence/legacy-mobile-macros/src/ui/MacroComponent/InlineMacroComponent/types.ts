import type { ExtensionParams } from '@atlaskit/editor-common/extensions';

export interface InlineMacroComponentProps {
  extension: ExtensionParams<any>;
}
