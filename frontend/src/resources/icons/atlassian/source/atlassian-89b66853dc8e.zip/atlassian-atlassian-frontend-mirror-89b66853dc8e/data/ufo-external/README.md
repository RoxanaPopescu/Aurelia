# UFO - external

Minimal subset of UFO available for components published to public npm

## Usage

``
npm install @atlaskit/ufo
``
