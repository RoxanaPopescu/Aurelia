# Embedded Confluence

Public release version of Embedded Confluence

## Usage

Detailed docs and example usage can be found [here](https://atlaskit.atlassian.com/packages/confluence/embedded-confluence-public).
