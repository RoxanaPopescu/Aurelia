export const NO_RETRIES = [] as const;
export const UP_TO_TWO_INSTANT_RETRIES = [0, 0] as const;
export const DEFAULT_RETRIES = [0, 50, 100] as const;
export const LAZY_LOAD_RETRIES = [100, 500, 1000] as const;
