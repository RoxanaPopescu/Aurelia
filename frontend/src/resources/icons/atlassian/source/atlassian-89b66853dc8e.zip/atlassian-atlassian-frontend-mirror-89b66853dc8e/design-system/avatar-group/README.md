# Avatar group

An avatar group displays a number of avatars grouped together in a stack or grid.

## Installation

```sh
yarn add @atlaskit/avatar-group
```

## Usage

Detailed docs and example usage can be found [here](https://atlassian.design/components/avatar-group/).
