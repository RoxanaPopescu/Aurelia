// temp solution until we can get it automated
export const UFO_EXPERIMENTAL_BUILD_VERSION = '0.1.5';
