export const roundPerfNow = () => ~~performance.now();
