# Panel

This is a React component that renders a collapsible panel

## Installation

```sh
yarn add @atlaskit/panel
```

## Usage

Detailed docs and example usage can be found [here](https://atlaskit.atlassian.com/packages/bitbucket/panel).
