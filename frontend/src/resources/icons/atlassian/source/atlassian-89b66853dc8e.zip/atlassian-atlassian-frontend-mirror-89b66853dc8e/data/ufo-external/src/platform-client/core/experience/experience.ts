import { UFOAbstractExperience } from './abstract-experience';

export class UFOExperience extends UFOAbstractExperience {}
