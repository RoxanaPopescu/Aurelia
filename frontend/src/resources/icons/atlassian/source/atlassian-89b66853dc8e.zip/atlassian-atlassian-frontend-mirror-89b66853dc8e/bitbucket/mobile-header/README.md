# Mobile Header

> React component rendering a mobile header, with a render prop for navigation

## Usage

Detailed docs and example usage can be found [here](https://atlaskit.atlassian.com/packages/bitbucket/mobile-header).

## Installation

```sh
yarn add @atlaskit/mobile-header
```

## Usage

Detailed docs and example usage can be found [here](https://atlaskit.atlassian.com/packages/bitbucket/mobile-header).
