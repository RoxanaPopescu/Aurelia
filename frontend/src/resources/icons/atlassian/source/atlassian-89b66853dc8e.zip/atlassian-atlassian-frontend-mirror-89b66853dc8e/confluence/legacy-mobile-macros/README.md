# LegacyMobileMacros

Higher-order components that optionally add Confluence-specific functionality to editor-mobile-bridge
