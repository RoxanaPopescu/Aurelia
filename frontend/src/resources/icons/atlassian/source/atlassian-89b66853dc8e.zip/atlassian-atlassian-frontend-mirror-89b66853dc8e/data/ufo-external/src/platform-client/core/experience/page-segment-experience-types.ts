export const PageSegmentExperienceTypes = {
  NAVIGATION: 'NAVIGATION',
  PRODUCT: 'PRODUCT',
  COMPONENT: 'COMPONENT',
};
