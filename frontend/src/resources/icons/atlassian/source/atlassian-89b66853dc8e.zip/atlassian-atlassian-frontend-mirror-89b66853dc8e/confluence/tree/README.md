# Tree

Use this component to any tree structure.

Features:

- Flexible tree rendering
- Dynamic tree expansion with lazy loading
