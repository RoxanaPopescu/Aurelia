# Analytics-next

Tools for tracking interactions with UI components. Easily capture UI context and state when these events occur.

## Installation

```sh
yarn add @atlaskit/analytics-next
```

## Usage

Detailed docs and example usage can be found [here](https://atlaskit.atlassian.com/packages/analytics/analytics-next).
