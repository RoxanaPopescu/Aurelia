export const macroExtensionHandlerKey = 'com.atlassian.confluence.macro.core';
