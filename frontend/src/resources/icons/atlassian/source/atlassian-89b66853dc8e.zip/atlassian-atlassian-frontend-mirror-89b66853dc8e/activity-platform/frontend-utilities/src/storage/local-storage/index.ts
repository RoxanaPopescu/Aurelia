export { STORAGE_MOCK, mockWindowStorage } from './main';
