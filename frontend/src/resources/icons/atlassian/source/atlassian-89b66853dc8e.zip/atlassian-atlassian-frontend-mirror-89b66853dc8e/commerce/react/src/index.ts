export { batchedUpdate } from './common/utils/batch';
