export const isWindowObjectAvailable = () => {
  return typeof window !== 'undefined';
};
