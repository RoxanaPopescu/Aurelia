module.exports = require('@github/prettier-config')
