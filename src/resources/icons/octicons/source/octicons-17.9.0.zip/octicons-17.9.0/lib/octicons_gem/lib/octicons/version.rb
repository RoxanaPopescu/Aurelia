module Octicons
  VERSION = "17.9.0".freeze
end
