module OcticonsHelper
  VERSION = "17.9.0".freeze
end
